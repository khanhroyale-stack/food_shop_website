import React from 'react';

const PrivateRouter = ({ element: Element, role }) => {
    const user = JSON.parse(localStorage.getItem('user'));

    if (!user || user.role !== role) {
        return <h1>Khong co quyen truy cap</h1>; 
    }

    return <Element />;
};

export default PrivateRouter;