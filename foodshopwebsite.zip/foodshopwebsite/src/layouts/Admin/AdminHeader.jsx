import React from 'react';
import '../styles/AdminHeader.css'; // Import the CSS file for styling

const AdminHeader = () => {
    return (
        <header className="header">
            <div className="header-content">
                <h1>Manage</h1>
                
            </div>
        </header>
    );
};

export default AdminHeader;